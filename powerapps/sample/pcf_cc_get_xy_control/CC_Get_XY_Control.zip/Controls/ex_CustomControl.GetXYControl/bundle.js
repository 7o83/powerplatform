/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./GetXYControl/index.ts":
/*!*******************************!*\
  !*** ./GetXYControl/index.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.GetXYControl = void 0;\nvar GetXYControl = /** @class */function () {\n  /** ADDend */\n  /**\n   * Empty constructor.\n   */\n  function GetXYControl() {}\n  GetXYControl.prototype.refreshData = function (evt) {\n    //console.log(\"call_refreshData\");\n    this._offsetX = evt.offsetX;\n    this._offsetY = evt.offsetY;\n    this._notifyOutputChanged();\n  };\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  GetXYControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    /** ADDstart */\n    //console.log(\"call_init\");\n    context.mode.trackContainerResize(true);\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._refreshData = this.refreshData.bind(this);\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this.targetDivElement = document.createElement(\"div\");\n    this._container.appendChild(this.targetDivElement);\n    container.appendChild(this._container);\n    this._display = context.parameters.display.raw;\n    //console.log(context.parameters.display);\n    this.targetDivElement.setAttribute(\"class\", this._display ? \"TargetRect\" : \"TargetRectTransparent\");\n    this.targetDivElement.addEventListener(\"click\", this._refreshData);\n    /** ADDend */\n  };\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  GetXYControl.prototype.updateView = function (context) {\n    // Add code to update control view\n    /** ADDstart */\n    //console.log(\"call_update\");\n    this.targetDivElement.style.setProperty(\"height\", this._context.mode.allocatedHeight.toString() + \"px\");\n    this.targetDivElement.style.setProperty(\"width\", this._context.mode.allocatedWidth.toString() + \"px\");\n    this._display = context.parameters.display.raw;\n    //console.log(context.parameters.display);\n    this.targetDivElement.setAttribute(\"class\", this._display ? \"TargetRect\" : \"TargetRectTransparent\");\n    /** ADDend */\n  };\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\n   */\n  GetXYControl.prototype.getOutputs = function () {\n    //console.log(\"call_output\");\n    return {\n      /** ADDstart */\n      offsetX: this._offsetX,\n      offsetY: this._offsetY,\n      display: this._display\n      /** ADDend */\n    };\n  };\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  GetXYControl.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n    /** ADDstart */\n    //console.log(\"call_destoroy\");\n    this.targetDivElement.removeEventListener(\"click\", this._refreshData);\n    /** ADDend */\n  };\n\n  return GetXYControl;\n}();\nexports.GetXYControl = GetXYControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./GetXYControl/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./GetXYControl/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CustomControl.GetXYControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GetXYControl);
} else {
	var CustomControl = CustomControl || {};
	CustomControl.GetXYControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GetXYControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}